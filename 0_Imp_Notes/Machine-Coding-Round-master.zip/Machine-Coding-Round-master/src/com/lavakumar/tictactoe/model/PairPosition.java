package com.lavakumar.tictactoe.model;

public class PairPosition {
    int start;
    int end;

    public PairPosition(int start, int end) {
        this.start = start;
        this.end = end;
    }
}
