package com.lavakumar.snakeandladder.model;

public class PairPosition {
    int start;
    int end;

    public PairPosition(int start, int end) {
        this.start = start;
        this.end = end;
    }
}
