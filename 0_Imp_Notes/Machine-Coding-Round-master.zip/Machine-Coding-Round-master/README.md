# Machine-Coding-Round
All LLD and Machine Coding Rounds Questions and Answers
1. Snake and Ladder
2. Tic-Tac-toe
3. Split Wise
4. Trello
5. Token Bucket

.. Countinued
